<?php
/**
 * @copyright	Copyright (C) 2009 ACYBA SARL - All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
?>
<?php
class templateClass extends acymailingClass{
  var $tables = array('template');
  var $pkey = 'tempid';
  var $namekey = 'alias';
  function get($tempid){
    $this->database->setQuery('SELECT * FROM '.acymailing::table('template').' WHERE tempid = '.intval($tempid).' LIMIT 1');
    $template = $this->database->loadObject();
    return $this->_prepareTemplate($template);
  }
  function getDefault(){
    $this->database->setQuery('SELECT * FROM '.acymailing::table('template').' WHERE premium = 1 AND published = 1 ORDER BY ordering ASC LIMIT 1');
    $template = $this->database->loadObject();
    return $this->_prepareTemplate($template);
  }
  function _prepareTemplate($template){
  	if(!isset($template->styles)) return $template;
    if(empty($template->styles)){
      $template->styles = array();
    }else{
      $template->styles = unserialize($template->styles);
    }
    return $template;
  }
  function saveForm(){
    $template = null;
    $template->tempid = acymailing::getCID('tempid');
    $formData = JRequest::getVar( 'data', array(), '', 'array' );
    foreach($formData['template'] as $column => $value){
      acymailing::secureField($column);
      $template->$column = strip_tags($value);
    }
    $styles = JRequest::getVar('styles',array(),'','array');
    foreach($styles as $class => $oneStyle){
      if(empty($oneStyle)) unset($styles[$class]);
    }
    $newStyles = JRequest::getVar('otherstyles',array(),'','array');
    if(!empty($newStyles)){
    	foreach($newStyles['classname'] as $id => $className){
    		if(!empty($className) AND $className != JText::_('CLASS_NAME') AND !empty($newStyles['style'][$id]) AND $newStyles['style'][$id] != JText::_('CSS_STYLE')){
    			$styles[$className] = $newStyles['style'][$id];
    		}
    	}
    }
    $template->styles = serialize($styles);
    $template->body = JRequest::getVar('editor_body','','','string',JREQUEST_ALLOWRAW);
    $template->description = JRequest::getVar('editor_description','','','string',JREQUEST_ALLOWRAW);
    $tempid = $this->save($template);
    if(!$tempid) return false;
    if(empty($template->tempid)){
      $orderClass = acymailing::get('helper.order');
      $orderClass->pkey = 'tempid';
      $orderClass->table = 'template';
      $orderClass->reOrder();
    }
    JRequest::setVar( 'tempid', $tempid);
    return true;
  }
  function save($element){
    if(empty($element->tempid)){
      if(empty($element->namekey)) $element->namekey = time().JFilterOutput::stringURLSafe($element->name);
    }
    return parent::save($element);
  }
}