<?php
/**
 * @copyright	Copyright (C) 2009 ACYBA SARL - All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
?>
<style type="text/css">
ul.familymenu
{
	list-style: none;
	padding: 0;
	margin: 0;
}
.familymenu li
{
	float: left;
	margin: 2px;
	padding : 2px 6px;
	display: block;
	border: 1px solid #dcdce9;
	color: #0d2474;
	text-align: center;
}
.familymenu li:hover
{
	background-color : #eee;
}
.familymenu li.selected{
	background-color : #eee;
	border: 2px solid #dcdce9;
	padding : 1px 5px;
}
#inserttagdiv{
	float:right;
}
#plugarea{
	float:left;
	clear:both;
	padding : 10px;
	width:700px;
}
table.adminlist tr.selectedrow td{
	background-color:#FDE2BA;
}
</style>
<ul class="familymenu" >
<?php
	if(empty($this->tagsfamilies)){ ?>
		You should see tags here!<br/>
		You probably had an error during installation<br/>
		Please make sure your plugins folders are writables :<br/>
			 * Joomla / Plugins<br/>
			 * Joomla / Plugins / User<br/>
			 * Joomla / Plugins / System<br/>
		And then <a href="index.php?option=com_acymailing&amp;gtask=update&amp;task=install&amp;tmpl=component">click here</a> to trigger the install process again.
	<?php }
	foreach ($this->tagsfamilies as $id => $oneFamily){
		if(empty($oneFamily)) continue;
		if($oneFamily->function == $this->fctplug){
			$help = empty($oneFamily->help) ? '' : $oneFamily->help;
			$class = ' class="selected" ';
		}
		else $class = '';
		echo '<li'.$class.'><a href='.acymailing::completeLink($this->gtask.'&task=tag&type='.$this->type.'&fctplug='.$oneFamily->function,true).'>'.$oneFamily->name.'</a></li>';
	}
?>
</ul>
<?php if(!empty($help) AND $this->app->isAdmin()){?>
<div style="float:right;padding:2px 4px;background-color:#CCCCCC;border:1px solid #AAAAAA;">
<?php include_once(ACYMAILING_BUTTON.DS.'pophelp.php');
	$helpButton = new JButtonPophelp();
	echo $helpButton->fetchButton('Pophelp',$help);
	?>
</div>
<div id="iframedoc" style="clear:both"></div>
<?php } ?>
<div id="inserttagdiv">
	<input class="inputbox" style="display:none" id="tagstring" name="tagstring" size="100" value="" onclick="this.select();"> <button style='display:none' id='insertButton' onclick="insertTag();"><?php echo JText::_('INSERT_TAG')?></button>
</div>
<form action="<?php echo JRoute::_('index.php?option=com_acymailing&tmpl=component'); ?>" method="post" name="adminForm" autocomplete="off">
<div id="plugarea">
	<?php echo $this->defaultContent;?>
</div>
<div class="clr"></div>
<input type="hidden" name="option" value="<?php echo ACYMAILING_COMPONENT; ?>" />
<input type="hidden" name="task" value="tag" />
<input type="hidden" id="fctplug" name="fctplug" value="<?php echo $this->fctplug; ?>"/>
<input type="hidden" name="type" value="<?php echo $this->type; ?>" />
<input type="hidden" name="gtask" value="<?php echo $this->gtask; ?>" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>