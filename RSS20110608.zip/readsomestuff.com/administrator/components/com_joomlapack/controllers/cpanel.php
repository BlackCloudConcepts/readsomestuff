<?php
/**
 * @package JoomlaPack
 * @copyright Copyright (c)2006-2008 JoomlaPack Developers
 * @license GNU General Public License version 2, or later
 * @version $id$
 * @since 1.3
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

// Load framework base classes
jimport('joomla.application.component.controller');

/**
 * The Control Panel controller class
 *
 */
class JoomlapackControllerCpanel extends JController 
{
	/**
	 * Displays the Control Panel (main page)
	 * Accessible at index.php?option=com_joomlapack
	 *
	 */
	function display()
	{
		// Make sure the user has seen the license nag screen
		$registry =& JoomlapackModelRegistry::getInstance();
		$nagscreen = $registry->get('nagscreen',false);
		
		if(!$nagscreen)
		{
			$this->setRedirect(JURI::base().'index.php?option=com_joomlapack&view=nag' );
			return;
		}
		
		// Invalidate stale backups
		jpimport('core.cube');
		JoomlapackCUBE::reset();

		// Display the panel
		parent::display();
	}
	
	function switchprofile()
	{
		$newProfile = JRequest::getInt('profileid', -10);
		
		if(!is_numeric($newProfile) || ($newProfile <= 0))
		{
			$this->setRedirect(JURI::base().'index.php?option='.JRequest::getCmd('option'), JText::_('PANEL_PROFILE_SWITCH_ERROR'), 'error' );
			return;			
		}
		
		$session =& JFactory::getSession();
		$session->set('profile', $newProfile, 'joomlapack');
		$this->setRedirect(JURI::base().'index.php?option='.JRequest::getCmd('option'), JText::_('PANEL_PROFILE_SWITCH_OK'));
	}
}