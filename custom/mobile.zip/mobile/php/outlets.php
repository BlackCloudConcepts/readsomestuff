<?php
function ShowOutlets($userid)
{
echo "<table cellspacing='0' cellpadding='0' border='0'>";
	$rs = GetUserOutlets($userid);
	while ($row = mysql_fetch_assoc($rs)) 
		{
			echo "<tr><td><a href='outlet_view.php?outlet_id=".$row['outlet_id']."' class='mylink'>".$row['name']."</a></td></tr>";
		}
echo "</table>";
}
?>